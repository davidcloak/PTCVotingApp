package com.example.votingapp.Connection;


public class ConnectionClass {
        public static String user = "Nate";
        public static String pass = "Ghost123";
        public static String database = "voteShield";
        public static String server = "voteshield.database.windows.net";
}

